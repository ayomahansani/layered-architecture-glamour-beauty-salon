package lk.ijse.salon.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import lk.ijse.salon.dto.ProductDto;
import lk.ijse.salon.model.ProductModel;
import lk.ijse.salon.tm.ProductTm;

import java.sql.SQLException;
import java.util.List;

public class ProductFormController {

    @FXML
    private AnchorPane productForm;

    @FXML
    private TextField txtCode;

    @FXML
    private TextField txtUnitPrice;

    @FXML
    private TextField txtName;

    @FXML
    private TextField txtQtyOnHand;

    @FXML
    private TextField txtType;

    @FXML
    private TableView<ProductTm> tblProduct;

    @FXML
    private TableColumn<?, ?> colCode;

    @FXML
    private TableColumn<?, ?> colName;

    @FXML
    private TableColumn<?, ?> colUnitPrice;

    @FXML
    private TableColumn<?, ?> colQtyOnHand;

    @FXML
    private TableColumn<?, ?> colAction;

    private ProductModel productModel = new ProductModel();

    public void initialize() {
        loadAllProducts();
        setCellValueFactory();
        tableListener();
    }

    private void tableListener() {
        tblProduct.getSelectionModel().selectedItemProperty().addListener((observable, oldValued, newValue) -> {
//            System.out.println(newValue);
            setData(newValue);
        });
    }

    private void setData(ProductTm row) {
        txtCode.setText(row.getCode());
        txtName.setText(row.getName());
        txtUnitPrice.setText(String.valueOf(row.getUnitPrice()));
        txtQtyOnHand.setText(String.valueOf(row.getQtyOnHand()));
    }

    private void setCellValueFactory() {
        colCode.setCellValueFactory(new PropertyValueFactory<>("code"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colUnitPrice.setCellValueFactory(new PropertyValueFactory<>("unitPrice"));
        colQtyOnHand.setCellValueFactory(new PropertyValueFactory<>("qtyOnHand"));
        colAction.setCellValueFactory(new PropertyValueFactory<>("btnAction"));
    }

    private void loadAllProducts() {
//        var model = new ItemModel();
        ObservableList<ProductTm> obList = FXCollections.observableArrayList();
        try {
            List<ProductDto> dtoList = productModel.loadAllProducts();

            for (ProductDto dto : dtoList) {
                obList.add(new ProductTm(
                        dto.getCode(),
                        dto.getName(),
                        dto.getUnitPrice(),
                        dto.getQtyOnHand(),
                        new Button("Delete")
                ));
            }
            tblProduct.setItems(obList);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    @FXML
    void btnClearOnAction(ActionEvent event) {
        clearFields();
    }

    @FXML
    void btnDeleteOnAction(ActionEvent event) {
        String code = txtCode.getText();

        //var model = new CustomerModel();
        try {
            boolean isDeleted = productModel.deleteProduct(code);
            if(isDeleted) {
                new Alert(Alert.AlertType.CONFIRMATION, "product deleted!").show();
            } else {
                new Alert(Alert.AlertType.CONFIRMATION, "product not deleted!").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    @FXML
    void btnSaveOnAction(ActionEvent event) {
        String code = txtCode.getText();
        String name = txtName.getText();
        String type = txtType.getText();
        double unitPrice = Double.parseDouble(txtUnitPrice.getText());
        int qtyOnHand = Integer.parseInt(txtQtyOnHand.getText());

        var dto = new ProductDto(code, name, type, unitPrice, qtyOnHand);

//        var model = new ItemModel();
        try {
            boolean isSaved = productModel.saveProduct(dto);
            if (isSaved) {
                new Alert(Alert.AlertType.CONFIRMATION, "product saved!").show();
                clearFields();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    @FXML
    void btnUpdateOnAction(ActionEvent event) {
        String code = txtCode.getText();
        String name = txtName.getText();
        String type = txtType.getText();
        double unitPrice = Double.parseDouble(txtUnitPrice.getText());
        int qtyOnHand = Integer.parseInt(txtQtyOnHand.getText());

//        var model = new ItemModel();
        try {
            boolean isUpdated = productModel.updateProduct(new ProductDto(code, name, type, unitPrice, qtyOnHand));
            if (isUpdated) {
                new Alert(Alert.AlertType.CONFIRMATION, "product updated").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    @FXML
    void codeSearchOnAction(ActionEvent event) {
        String code = txtCode.getText();

        try {
            ProductDto dto = productModel.searchProduct(code);
            if (dto != null) {
                setFields(dto);
            } else {
                new Alert(Alert.AlertType.INFORMATION, "item not found!").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }

    }

    private void clearFields() {
        txtCode.clear();
        txtName.clear();
        txtType.clear();
        txtUnitPrice.clear();
        txtQtyOnHand.clear();
    }

    private void setFields(ProductDto dto) {
        txtCode.setText(dto.getCode());
        txtName.setText(dto.getName());
        txtType.setText(dto.getType());
        txtUnitPrice.setText(String.valueOf(dto.getUnitPrice()));
        txtQtyOnHand.setText(String.valueOf(dto.getQtyOnHand()));
    }

}
