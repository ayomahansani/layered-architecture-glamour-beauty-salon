package lk.ijse.salon.model;

import lk.ijse.salon.db.DbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AppointmentModel {

    public String generateNextAppointmentId() throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "SELECT app_id FROM appointment ORDER BY app_id DESC LIMIT 1";
        PreparedStatement pstm = connection.prepareStatement(sql);

        ResultSet resultSet = pstm.executeQuery();

        if(resultSet.next()){
            String id = resultSet.getString(1);
            return splitAppointmentId(id);
        }
        return splitAppointmentId(null);
    }

    private String splitAppointmentId(String currentAppId) {
        if(currentAppId != null) {
            String[] split = currentAppId.split("A0");
            int id = Integer.parseInt(split[1]);
            id++;
            return "A00" + id;
        } else {
            return "A001";
        }
    }
}
