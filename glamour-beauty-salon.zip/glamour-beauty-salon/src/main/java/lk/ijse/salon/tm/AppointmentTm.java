package lk.ijse.salon.tm;

public class AppointmentTm {
}
