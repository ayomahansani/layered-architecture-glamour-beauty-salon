package lk.ijse.salon.model;

import lk.ijse.salon.db.DbConnection;
import lk.ijse.salon.dto.ProductDto;
import lk.ijse.salon.tm.OrderCartTm;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductModel {

    public boolean saveProduct(ProductDto productDto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        String sql = "INSERT INTO product VALUES(?, ?, ?, ?, ?)";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, productDto.getCode());
        pstm.setString(2, productDto.getName());
        pstm.setString(3, productDto.getType());
        pstm.setDouble(4, productDto.getUnitPrice());
        pstm.setInt(5, productDto.getQtyOnHand());

        return pstm.executeUpdate() > 0;
    }

    public boolean updateProduct(ProductDto productDto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "UPDATE product SET pr_name = ?, pr_type = ?, pr_unit_price = ?, pr_qty_on_hand = ? WHERE pr_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, productDto.getName());
        pstm.setString(2, productDto.getType());
        pstm.setDouble(2, productDto.getUnitPrice());
        pstm.setInt(3, productDto.getQtyOnHand());
        pstm.setString(4, productDto.getCode());

        return pstm.executeUpdate() > 0;
    }

    public ProductDto searchProduct(String code) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        String sql = "SELECT * FROM product WHERE pr_id = ?";

        PreparedStatement pstm = connection.prepareStatement(sql);
        pstm.setString(1, code);

        ResultSet resultSet = pstm.executeQuery();

        ProductDto dto = null;

        if(resultSet.next()) {
            dto = new ProductDto(
                    resultSet.getString(1),
                    resultSet.getString(2),
                    resultSet.getString(3),
                    resultSet.getDouble(4),
                    resultSet.getInt(5)
            );
        }
        return dto;
    }

    public boolean deleteProduct(String code) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "DELETE FROM product WHERE pr_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, code);

        return pstm.executeUpdate() > 0;
    }

    public List<ProductDto> loadAllProducts() throws SQLException {

        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "SELECT * FROM product";
        PreparedStatement pstm = connection.prepareStatement(sql);

        List<ProductDto> itemList = new ArrayList<>();

        ResultSet resultSet = pstm.executeQuery();
        while (resultSet.next()) {
            itemList.add(new ProductDto(
                    resultSet.getString(1),
                    resultSet.getString(2),
                    resultSet.getString(3),
                    resultSet.getDouble(4),
                    resultSet.getInt(5)
            ));
        }

        return itemList;
    }

    public boolean updateProduct(List<OrderCartTm> cartTmList) throws SQLException {
        for(OrderCartTm tm : cartTmList) {
            if(!updateQty(tm.getCode(), tm.getQty())) {
                return false;
            }
        }
        return true;
    }

    public boolean updateQty(String code, int qty) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "UPDATE product SET pr_qty_on_hand = product.pr_qty_on_hand - ? WHERE pr_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setInt(1, qty);
        pstm.setString(2, code);

        return pstm.executeUpdate() > 0; //false
    }
}
