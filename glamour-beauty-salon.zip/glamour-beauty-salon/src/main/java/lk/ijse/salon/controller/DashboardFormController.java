package lk.ijse.salon.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

public class DashboardFormController {
    @FXML
    private AnchorPane dashboard;

    @FXML
    private Label lblNoOfOrders;

    @FXML
    private Label lblNoOfAppointments;

    @FXML
    private Label lblNoOfServices;

    @FXML
    private Label lblNoOfProducts;

    @FXML
    private Label lblNoOfCustomers;
}

