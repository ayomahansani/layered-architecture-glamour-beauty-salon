package lk.ijse.salon.model;

import lk.ijse.salon.db.DbConnection;
import lk.ijse.salon.dto.LoginDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginModel {
    static String userName;
    static String password;
    static String email;
    static String body;

    /*public static boolean checkUsername(LoginDto loginDto) throws SQLException {
        Connection connection= DbConnection.getInstance().getConnection();
        String sql="select * from user";
        PreparedStatement pstm=connection.prepareStatement(sql);
        ResultSet resultSet= pstm.executeQuery();
        while (resultSet.next()){
            userName=resultSet.getString(1);
            if(("sayurivithana@gmail.com".equals(loginDto.getUserName())) | ("nipunichan@gmail.com".equals(loginDto.getUserName()))){
                return false;
            }
        }
        return false;
    }
    public static boolean checkPassword(LoginDto loginDto) throws SQLException {
        Connection connection= DbConnection.getInstance().getConnection();
        String sql="select * from user";
        PreparedStatement pstm=connection.prepareStatement(sql);
        ResultSet resultSet= pstm.executeQuery();
        while (resultSet.next()){
            password=resultSet.getString(2);
            if(("sayuri987".equals(loginDto.getPassword())) | ("nipuni123".equals(loginDto.getPassword()))){
                return true;
            }

        }
        return false;
    }*/

    public static boolean checkCreditinal(LoginDto loginDto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "select * from user";
        PreparedStatement pstm = connection.prepareStatement(sql);

        ResultSet resultSet = pstm.executeQuery();
        while (resultSet.next()){
            userName = resultSet.getString("user_name");
            password = resultSet.getString("password");

            if(loginDto.getUserName().equals(userName)){
                if (loginDto.getPassword().equals(password)){
                    return true;
                }
            }
        }
        return false;
    }
}
