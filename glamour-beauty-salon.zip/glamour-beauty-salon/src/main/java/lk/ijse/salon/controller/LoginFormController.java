package lk.ijse.salon.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.salon.dto.LoginDto;
import lk.ijse.salon.model.LoginModel;

import java.io.IOException;
import java.sql.SQLException;

public class LoginFormController {
    @FXML
    private AnchorPane loginpage;
    @FXML
    private Button btnLogin;
    @FXML
    private TextField txtPassword;

    @FXML
    private TextField txtUsername;
    static LoginDto loginDto = new LoginDto();

    public void btnLoginOnAction(ActionEvent actionEvent) throws IOException, SQLException {
        String userName = txtUsername.getText();
        String password = txtPassword.getText();
        //var loginDto=new UserDto(userName,password);
        loginDto.setPassword(password);
        loginDto.setUserName(userName);

        boolean isMatched=LoginModel.checkCreditinal(loginDto);

        if(isMatched==false){
            new Alert(Alert.AlertType.CONFIRMATION, "wrong username or password try again!").show();
        }
        else
        {
            AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/main_form.fxml"));
            Scene scene = new Scene(anchorPane);
            Stage stage = (Stage) loginpage.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Dashboard");
            stage.centerOnScreen();
        }

    }

    public void forgetPasswordOnAction(ActionEvent actionEvent) throws IOException {
        Parent rootNode = FXMLLoader.load(this.getClass().getResource("/view/forgotpassword_form.fxml"));

        Scene scene = new Scene(rootNode);

        loginpage.getChildren().clear();
        Stage primaryStage = (Stage) loginpage.getScene().getWindow();

        primaryStage.setScene(scene);
        primaryStage.setTitle("Reset Password Form");
    }

    public void signupOnAction(ActionEvent actionEvent) throws IOException {
        Parent rootNode = FXMLLoader.load(this.getClass().getResource("/view/signup_form.fxml"));

        Scene scene = new Scene(rootNode);

        loginpage.getChildren().clear();
        Stage primaryStage = (Stage) loginpage.getScene().getWindow();

        primaryStage.setScene(scene);
        primaryStage.setTitle("Signup Form");
    }
}
