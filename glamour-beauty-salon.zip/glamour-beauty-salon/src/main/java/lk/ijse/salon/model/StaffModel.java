package lk.ijse.salon.model;

import lk.ijse.salon.db.DbConnection;
import lk.ijse.salon.dto.CustomerDto;
import lk.ijse.salon.dto.StaffDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StaffModel {
    public boolean saveStaff(StaffDto dto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "INSERT INTO staff VALUES(?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, dto.getStaffId());
        pstm.setString(2, dto.getStaffName());
        pstm.setString(3, dto.getStaffAddress());
        pstm.setString(4, dto.getStaffEmail());
        pstm.setString(5, dto.getStaffTel());
        pstm.setString(6, dto.getStaffType());
        pstm.setString(7, dto.getScheduleTime());

        boolean isSaved = pstm.executeUpdate() > 0;

        return isSaved;
    }

    public boolean updateStaff(StaffDto dto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "UPDATE staff SET st_name = ?, st_address = ?, st_email = ?, st_tel = ?, st_type = ?, schedule_time = ? WHERE st_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, dto.getStaffName());
        pstm.setString(2, dto.getStaffAddress());
        pstm.setString(3, dto.getStaffEmail());
        pstm.setString(4, dto.getStaffTel());
        pstm.setString(5, dto.getStaffType());
        pstm.setString(6, dto.getScheduleTime());
        pstm.setString(7, dto.getStaffId());

        return pstm.executeUpdate() > 0;
    }

    public StaffDto searchStaff(String id) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection ();

        String sql = "SELECT * FROM staff WHERE st_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);
        pstm.setString(1, id);

        ResultSet resultSet = pstm.executeQuery();

        StaffDto dto = null;

        if(resultSet.next()) {
            String st_id = resultSet.getString(1);
            String st_name = resultSet.getString(2);
            String st_address = resultSet.getString(3);
            String st_email = resultSet.getString(4);
            String st_tel = resultSet.getString(5);
            String st_type = resultSet.getString(6);
            String schedule_time = resultSet.getString(7);

            dto = new StaffDto(st_id, st_name, st_address, st_email, st_tel, st_type, schedule_time);
        }
        return dto;
    }

    public boolean deleteStaff(String id) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "DELETE FROM staff WHERE st_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, id);

        return pstm.executeUpdate() > 0;
    }

    public List<StaffDto> getAllStaff() throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "SELECT * FROM staff";
        PreparedStatement pstm = connection.prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();

        ArrayList<StaffDto> dtoList = new ArrayList<>();

        while(resultSet.next()) {
            dtoList.add(
                    new StaffDto(
                            resultSet.getString(1),
                            resultSet.getString(2),
                            resultSet.getString(3),
                            resultSet.getString(4),
                            resultSet.getString(5),
                            resultSet.getString(6),
                            resultSet.getString(7)
                    )
            );
        }
        return dtoList;
    }
}
