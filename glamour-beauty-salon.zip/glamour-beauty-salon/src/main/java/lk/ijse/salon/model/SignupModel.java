package lk.ijse.salon.model;

import lk.ijse.salon.db.DbConnection;
import lk.ijse.salon.dto.SignupDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SignupModel {
    public static boolean userSignup(SignupDto signupDto) throws SQLException, ClassNotFoundException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "INSERT INTO user VALUES(?,?,?)";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, signupDto.getFullName());
        pstm.setString(2, signupDto.getEmail());
        pstm.setString(3, signupDto.getPassword());

        int affectedRow = pstm.executeUpdate();

        if (affectedRow > 0) {
            return true;
        } else {
            return false;
        }
    }
}
