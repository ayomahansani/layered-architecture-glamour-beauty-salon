package lk.ijse.salon.controller;

import com.jfoenix.controls.JFXComboBox;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;

public class PaymentFormController {

    @FXML
    private AnchorPane paymentForm;

    @FXML
    private JFXComboBox<?> cmbCustomerId;

    @FXML
    private TableView<?> tblPayment;

    @FXML
    private TableColumn<?, ?> colPaymentId;

    @FXML
    private TableColumn<?, ?> colCustomerId;

    @FXML
    private TableColumn<?, ?> colPaymentDate;

    @FXML
    private TableColumn<?, ?> colPaymentTime;

    @FXML
    private TableColumn<?, ?> colAppointmentAmount;

    @FXML
    private TableColumn<?, ?> colOrderAmount;

    @FXML
    private TableColumn<?, ?> colTotalAmount;

    @FXML
    private Button btnTotalAmount;

    @FXML
    private Label lblAppointmentAmount;

    @FXML
    private Label lblOrderAmount;

    @FXML
    private Label lblPaymentId;

    @FXML
    private Label lblPaymentDate;

    @FXML
    private Label lblPaymentTime;

    @FXML
    void btnTotalAmountOnAction(ActionEvent event) {

    }

    @FXML
    void cmbCustomerOnAction(ActionEvent event) {

    }

}
