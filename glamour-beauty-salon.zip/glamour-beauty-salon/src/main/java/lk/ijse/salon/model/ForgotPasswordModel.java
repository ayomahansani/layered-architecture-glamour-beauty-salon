package lk.ijse.salon.model;

import lk.ijse.salon.db.DbConnection;
import lk.ijse.salon.dto.ForgotPasswordDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ForgotPasswordModel {
    public boolean checkUserName(String userName) throws SQLException {

        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "SELECT user_name FROM user";
        PreparedStatement pstm = connection.prepareStatement(sql);

        ResultSet resultSet = pstm.executeQuery();
        while ((resultSet.next())){
            String email =  resultSet.getString(2);
                if(email.equals(userName)){
                    return true;
                }
        }
        return false;
    }

    public boolean setPassword(ForgotPasswordDto dto) throws SQLException {

        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "UPDATE user SET password = ? WHERE user_name = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, dto.getPassword());
        pstm.setString(2, dto.getUserName());

        return pstm.executeUpdate() > 0;
    }
}
