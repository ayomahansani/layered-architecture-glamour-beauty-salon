package lk.ijse.salon.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.salon.dto.CustomerDto;
import lk.ijse.salon.dto.ServiceDto;
import lk.ijse.salon.dto.StaffDto;
import lk.ijse.salon.model.AppointmentModel;
import lk.ijse.salon.model.CustomerModel;
import lk.ijse.salon.model.ServiceModel;
import lk.ijse.salon.model.StaffModel;
import lk.ijse.salon.tm.AppointmentTm;

import java.io.IOException;
import java.sql.SQLException;

public class AppointmentFormController {

    @FXML
    private AnchorPane appointmentForm;

    @FXML
    private JFXButton btnSaveAppointment;

    @FXML
    private TableView<AppointmentTm> tblAppointments;

    @FXML
    private TableColumn<?, ?> colServiceId;

    @FXML
    private TableColumn<?, ?> colServiceName;

    @FXML
    private TableColumn<?, ?> colServiceAmount;

    @FXML
    private TableColumn<?, ?> colAction;

    @FXML
    private Label lblAppointmentId;

    @FXML
    private Label lblAppointmentDate;

    @FXML
    private Label lblCustomerName;

    @FXML
    private JFXComboBox<String> cmbCustomerId;

    @FXML
    private JFXComboBox<String> cmbServiceId;

    @FXML
    private Label lblServiceName;

    @FXML
    private Label lblServiceAmount;

    @FXML
    private JFXButton btnNewCustomer;

    @FXML
    private JFXButton btnDateAvailibility;

    @FXML
    private JFXComboBox<String> cmbStaffId;

    @FXML
    private Label lblStaffName;

    @FXML
    private JFXButton btnStaffAvailibility;

    @FXML
    private JFXButton btnConfirmedAppointment;

    @FXML
    private Label lblNetTotal;

    private AppointmentModel appointmentModel = new AppointmentModel();

    private CustomerModel customerModel = new CustomerModel();

    private ServiceModel serviceModel = new ServiceModel();

    private StaffModel staffModel = new StaffModel();

    public void initialize() {
        generateNextAppointmentId();
    }

    private void generateNextAppointmentId() {
        try {
            String appId = appointmentModel.generateNextAppointmentId();
            lblAppointmentId.setText(appId);
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    @FXML
    void btnConfirmedAppointmentOnAction(ActionEvent event) {

    }

    @FXML
    void btnDateAvailibilityOnAction(ActionEvent event) {

    }

    @FXML
    void btnNewCustomerOnAction(ActionEvent event) throws IOException {
        Parent anchorPane = FXMLLoader.load(getClass().getResource("/view/customer_form.fxml"));
        Scene scene = new Scene(anchorPane);

        Stage stage = new Stage();
        stage.setTitle("Customer Manage");
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.show();
    }

    @FXML
    void btnSaveAppointmentOnAction(ActionEvent event) {

    }

    @FXML
    void btnStaffAvailibilityOnAction(ActionEvent event) {

    }

    @FXML
    void cmbCustomerOnAction(ActionEvent event) {
        String id = cmbCustomerId.getValue();
//        CustomerModel customerModel = new CustomerModel();
        try {
            CustomerDto customerDto = customerModel.searchCustomer(id);
            lblCustomerName.setText(customerDto.getCusName());

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void cmbServiceIdOnAction(ActionEvent event) {
        String id = cmbServiceId.getValue();
//        ServiceModel serviceModel = new ServiceModel();
        try {
            ServiceDto serviceDto = serviceModel.searchService(id);
            lblServiceName.setText(serviceDto.getServiceName());
            lblServiceAmount.setText(String.valueOf(serviceDto.getServiceAmount()));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void cmbStaffIdOnAction(ActionEvent event) {
        String id = cmbStaffId.getValue();
        //StaffModel staffModel = new StaffModel();
        try {
            StaffDto staffDto = staffModel.searchStaff(id);
            lblCustomerName.setText(staffDto.getStaffName());

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
