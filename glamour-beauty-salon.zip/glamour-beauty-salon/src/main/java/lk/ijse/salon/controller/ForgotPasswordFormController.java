package lk.ijse.salon.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.salon.dto.ForgotPasswordDto;
import lk.ijse.salon.model.ForgotPasswordModel;

import java.io.IOException;
import java.sql.SQLException;

public class ForgotPasswordFormController {
    public TextField txtPwd;
    public Button btnReset;
    public TextField txtUserName;
    public Label lblAlert1;
    public AnchorPane forgotpwpage;

    private ForgotPasswordModel forgotPasswordModel = new ForgotPasswordModel();


    public void btnResetPasswordOnAction(ActionEvent actionEvent) throws IOException {

        /*String userName = txtUserName.getText();
        try {
            boolean isCheck = forgotPasswordModel.checkUserName(userName);
            if (isCheck){
                String pw = txtPwd.getText();

                    var dto = new ForgotPasswordDto(userName, pw);

                    boolean isSet = forgotPasswordModel.setPassword(dto);
                    if (isSet) {*/
                        new Alert(Alert.AlertType.CONFIRMATION, "Password Reset successful!!").show();

                        Parent rootNode = FXMLLoader.load(this.getClass().getResource("/view/login_form.fxml"));

                        Scene scene = new Scene(rootNode);

                        forgotpwpage.getChildren().clear();
                        Stage primaryStage = (Stage) forgotpwpage.getScene().getWindow();

                        primaryStage.setScene(scene);
                        primaryStage.setTitle("Login Form");
                    }/*
                }
            else{
                lblAlert1.setText("Username is incorrect");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }*/
}
