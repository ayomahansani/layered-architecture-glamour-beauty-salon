package lk.ijse.salon.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;

public class MainFormController {

    @FXML
    private AnchorPane main;

    @FXML
    private Button btnDashboard;

    @FXML
    private Button btnCustomers;

    @FXML
    private Button btnAppointments;

    @FXML
    private Button btnOrders;

    @FXML
    private Button btnPayment;

    @FXML
    private Button btnServices;

    @FXML
    private Button btnStaff;

    @FXML
    private Button btnProducts;

    @FXML
    private AnchorPane dashboard;

    @FXML
    void btnAppointmentsOnAction(ActionEvent event) throws IOException {
        Parent form = FXMLLoader.load(getClass().getResource("/view/appointment_form.fxml"));

        this.dashboard.getChildren().clear();
        this.dashboard.getChildren().add(form);
    }

    @FXML
    void btnCustomersOnAction(ActionEvent event) throws IOException {
        Parent form = FXMLLoader.load(getClass().getResource("/view/customer_form.fxml"));

        this.dashboard.getChildren().clear();
        this.dashboard.getChildren().add(form);
    }

    @FXML
    void btnDashboardOnAction(ActionEvent event) throws IOException {
        Parent form = FXMLLoader.load(getClass().getResource("/view/dashboard_form.fxml"));

        this.dashboard.getChildren().clear();
        this.dashboard.getChildren().add(form);
    }

    @FXML
    void btnOrdersOnAction(ActionEvent event) throws IOException {
        Parent form = FXMLLoader.load(getClass().getResource("/view/placeorder_form.fxml"));

        this.dashboard.getChildren().clear();
        this.dashboard.getChildren().add(form);
    }

    @FXML
    void btnPaymentOnAction(ActionEvent event) throws IOException {
        Parent form = FXMLLoader.load(getClass().getResource("/view/payment_form.fxml"));

        this.dashboard.getChildren().clear();
        this.dashboard.getChildren().add(form);
    }

    @FXML
    void btnProductsOnAction(ActionEvent event) throws IOException {
        Parent form = FXMLLoader.load(getClass().getResource("/view/product_form.fxml"));

        this.dashboard.getChildren().clear();
        this.dashboard.getChildren().add(form);
    }

    @FXML
    void btnServicesOnAction(ActionEvent event) throws IOException {
        Parent form = FXMLLoader.load(getClass().getResource("/view/service_form.fxml"));

        this.dashboard.getChildren().clear();
        this.dashboard.getChildren().add(form);
    }

    @FXML
    void btnStaffOnAction(ActionEvent event) throws IOException {
        Parent form = FXMLLoader.load(getClass().getResource("/view/staff_form.fxml"));

        this.dashboard.getChildren().clear();
        this.dashboard.getChildren().add(form);
    }

}
