package lk.ijse.salon.model;

import lk.ijse.salon.db.DbConnection;
import lk.ijse.salon.dto.CustomerDto;
import lk.ijse.salon.dto.ServiceDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServiceModel {

    public boolean saveService(ServiceDto dto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "INSERT INTO service VALUES(?, ?, ?, ?)";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, dto.getServiceId());
        pstm.setString(2, dto.getServiceName());
        pstm.setString(3, dto.getServiceType());
        pstm.setString(4, String.valueOf(dto.getServiceAmount()));

        boolean isSaved = pstm.executeUpdate() > 0;

        return isSaved;
    }

    public boolean updateService(ServiceDto dto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "UPDATE service SET ser_name = ?, ser_type = ?, ser_unit_price = ? WHERE ser_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);
        pstm.setString(1, dto.getServiceName());
        pstm.setString(2, dto.getServiceType());
        pstm.setString(3, String.valueOf(dto.getServiceAmount()));
        pstm.setString(4, dto.getServiceId());

        return pstm.executeUpdate() > 0;
    }

    public boolean deleteService(String id) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "DELETE FROM service WHERE ser_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, id);

        return pstm.executeUpdate() > 0;
    }

    public ServiceDto searchService(String id) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection ();

        String sql = "SELECT * FROM service WHERE ser_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);
        pstm.setString(1, id);

        ResultSet resultSet = pstm.executeQuery();

        ServiceDto dto = null;

        if(resultSet.next()) {
            String ser_id = resultSet.getString(1);
            String ser_name = resultSet.getString(2);
            String ser_type = resultSet.getString(3);
            double ser_amount = resultSet.getDouble(4);

            dto = new ServiceDto(ser_id, ser_name, ser_type, ser_amount);
        }
        return dto;
    }

    public List<ServiceDto> getAllServices() throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "SELECT * FROM service";
        PreparedStatement pstm = connection.prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();

        ArrayList<ServiceDto> dtoList = new ArrayList<>();

        while(resultSet.next()) {
            dtoList.add(
                    new ServiceDto(
                            resultSet.getString(1),
                            resultSet.getString(2),
                            resultSet.getString(3),
                            resultSet.getDouble(4)
                    )
            );
        }
        return dtoList;
    }
}
