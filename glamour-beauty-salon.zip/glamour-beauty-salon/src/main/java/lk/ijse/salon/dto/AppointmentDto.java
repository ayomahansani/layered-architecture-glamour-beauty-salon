package lk.ijse.salon.dto;

public class AppointmentDto {
}
