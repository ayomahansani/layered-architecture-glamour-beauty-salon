package lk.ijse.salon.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import lk.ijse.salon.dto.CustomerDto;
import lk.ijse.salon.dto.StaffDto;
import lk.ijse.salon.model.CustomerModel;
import lk.ijse.salon.model.StaffModel;
import lk.ijse.salon.tm.CustomerTm;
import lk.ijse.salon.tm.StaffTm;

import java.sql.SQLException;
import java.util.List;

public class StaffFormController {

    @FXML
    private AnchorPane staffForm;

    @FXML
    private TextField txtStaffId;

    @FXML
    private TextField txtStaffName;

    @FXML
    private TextField txtStaffEmail;

    @FXML
    private TextField txtStaffType;

    @FXML
    private TableView<StaffTm> tblStaff;

    @FXML
    private TableColumn<?, ?> colStaffId;

    @FXML
    private TableColumn<?, ?> colStaffName;

    @FXML
    private TableColumn<?, ?> colStaffAddress;

    @FXML
    private TableColumn<?, ?> colStaffEmail;

    @FXML
    private TableColumn<?, ?> colStaffType;

    @FXML
    private TableColumn<?, ?> colScheduleTime;

    @FXML
    private TableColumn<?, ?> colStaffTel;

    @FXML
    private TextField txtStaffAddress;

    @FXML
    private TextField txtScheduleTime;

    @FXML
    private TextField txtPhone;

    private StaffModel staffModel = new StaffModel();

    public void initialize(){
        setCellValueFactory();
        loadAllStaff();
    }

    private void setCellValueFactory() {
        colStaffId.setCellValueFactory(new PropertyValueFactory<>("Staff Id"));
        colStaffName.setCellValueFactory(new PropertyValueFactory<>("Staff Name"));
        colStaffAddress.setCellValueFactory(new PropertyValueFactory<>("Staff Address"));
        colStaffEmail.setCellValueFactory(new PropertyValueFactory<>("Staff Email"));
        colStaffType.setCellValueFactory(new PropertyValueFactory<>("Staff Type"));
        colScheduleTime.setCellValueFactory(new PropertyValueFactory<>("Schedule Time"));
        colStaffTel.setCellValueFactory(new PropertyValueFactory<>("Staff Tel"));
    }

    private void loadAllStaff()  {
        var model = new StaffModel();

        ObservableList<StaffTm> obList = FXCollections.observableArrayList();

        try {
            List<StaffDto> dtoList = model.getAllStaff();

            for (StaffDto dto : dtoList) {
                obList.add(
                        new StaffTm(
                                dto.getStaffId(),
                                dto.getStaffName(),
                                dto.getStaffAddress(),
                                dto.getStaffEmail(),
                                dto.getStaffType(),
                                dto.getScheduleTime(),
                                dto.getStaffTel()
                        )
                );
            }

            tblStaff.setItems(obList);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @FXML
    void btnClearOnAction(ActionEvent event) {
        clearFields();
    }

    @FXML
    void btnDeleteOnAction(ActionEvent event) {
        String id = txtStaffId.getText();

        //var model = new StaffModel();
        try {
            boolean isDeleted = staffModel.deleteStaff(id);
            if(isDeleted) {
                new Alert(Alert.AlertType.CONFIRMATION, "staff member deleted!").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    @FXML
    void btnSaveOnAction(ActionEvent event) {
        String id = txtStaffId.getText();
        String name = txtStaffName.getText();
        String address = txtStaffAddress.getText();
        String email = txtStaffEmail.getText();
        String tel = txtPhone.getText();
        String type = txtStaffType.getText();
        String schedule_time = txtScheduleTime.getText();

            var dto = new StaffDto(id, name, address, email, tel, type, schedule_time);

            try {
                boolean isSaved = staffModel.saveStaff(dto);

                if (isSaved) {
                    new Alert(Alert.AlertType.CONFIRMATION, "new staff member added!").show();
                    clearFields();
                }
            } catch (SQLException e) {
                new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
            }
    }

    private void clearFields() {
        txtStaffId.setText("");
        txtStaffName.setText("");
        txtStaffAddress.setText("");
        txtStaffEmail.setText("");
        txtPhone.setText("");
        txtStaffType.setText("");
        txtScheduleTime.setText("");
    }

    @FXML
    void btnUpdateOnAction(ActionEvent event) {
        String id = txtStaffId.getText();
        String name = txtStaffName.getText();
        String address = txtStaffAddress.getText();
        String email = txtStaffEmail.getText();
        String tel = txtPhone.getText();
        String type = txtStaffType.getText();
        String schedule_time = txtScheduleTime.getText();

        var dto = new StaffDto(id, name, address, email, tel, type, schedule_time);

            //var model = new StaffModel();
            try {
                boolean isUpdated = staffModel.updateStaff(dto);
                if(isUpdated) {
                    new Alert(Alert.AlertType.CONFIRMATION, "staff member updated!").show();
                    clearFields();
                }
            } catch (SQLException e) {
                new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
            }
    }

    @FXML
    void txtSearchOnAction(ActionEvent event) {
        String id = txtStaffId.getText();

        //var model = new StaffModel();
        try {
            StaffDto staffDto = staffModel.searchStaff(id);
            System.out.println(staffDto);
            if (staffDto != null) {
                txtStaffId.setText(staffDto.getStaffId());
                txtStaffName.setText(staffDto.getStaffName());
                txtStaffAddress.setText(staffDto.getStaffAddress());
                txtStaffEmail.setText(staffDto.getStaffEmail());
                txtPhone.setText(staffDto.getStaffTel());
                txtStaffType.setText(staffDto.getStaffType());
                txtScheduleTime.setText(staffDto.getScheduleTime());
            } else {
                new Alert(Alert.AlertType.INFORMATION, "staff member not found").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }
}
