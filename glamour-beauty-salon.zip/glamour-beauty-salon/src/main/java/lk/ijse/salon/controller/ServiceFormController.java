package lk.ijse.salon.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import lk.ijse.salon.dto.CustomerDto;
import lk.ijse.salon.dto.ServiceDto;
import lk.ijse.salon.model.CustomerModel;
import lk.ijse.salon.model.ServiceModel;
import lk.ijse.salon.tm.CustomerTm;
import lk.ijse.salon.tm.ServiceTm;

import java.sql.SQLException;
import java.util.List;

public class ServiceFormController {

    @FXML
    private AnchorPane serviceForm;

    @FXML
    private TextField txtSerId;

    @FXML
    private TextField txtSerType;

    @FXML
    private TextField txtSerName;

    @FXML
    private TextField txtSerAmount;

    @FXML
    private TableView<ServiceTm> tblServices;

    @FXML
    private TableColumn<?, ?> colServiceId;

    @FXML
    private TableColumn<?, ?> colServiceName;

    @FXML
    private TableColumn<?, ?> colServiceType;

    @FXML
    private TableColumn<?, ?> colServiceAmount;


    private ServiceModel serviceModel = new ServiceModel();

    public void initialize(){
        setCellValueFactory();
        loadAllServices();
    }

    private void setCellValueFactory() {
        colServiceId.setCellValueFactory(new PropertyValueFactory<>("serviceId"));
        colServiceName.setCellValueFactory(new PropertyValueFactory<>("serviceName"));
        colServiceType.setCellValueFactory(new PropertyValueFactory<>("serviceType"));
        colServiceAmount.setCellValueFactory(new PropertyValueFactory<>("serviceAmount"));
    }

    private void loadAllServices()  {
        var model = new ServiceModel();

        ObservableList<ServiceTm> obList = FXCollections.observableArrayList();

        List<ServiceDto> dtoList = null;
        try {
            dtoList = model.getAllServices();

            for (ServiceDto dto : dtoList) {
                obList.add(
                        new ServiceTm(
                                dto.getServiceId(),
                                dto.getServiceName(),
                                dto.getServiceType(),
                                dto.getServiceAmount()
                        )
                );
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        tblServices.setItems(obList);

    }

    @FXML
    void btnClearOnAction(ActionEvent event) {
        clearFields();
    }

    @FXML
    void btnDeleteOnAction(ActionEvent event) {
        String id = txtSerId.getText();

        //var model = new ServiceModel();
        boolean isDeleted = false;
        try {
            isDeleted = serviceModel.deleteService(id);
            if(isDeleted) {
                new Alert(Alert.AlertType.CONFIRMATION, "service deleted!").show();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void btnSaveOnAction(ActionEvent event) {
        String id = txtSerId.getText();
        String name = txtSerName.getText();
        String type = txtSerType.getText();
        double amount = Double.parseDouble(txtSerAmount.getText());

            var dto = new ServiceDto(id, name, type, amount);

        boolean isSaved = false;
        try {
            isSaved = serviceModel.saveService(dto);
            if (isSaved) {
                new Alert(Alert.AlertType.CONFIRMATION, "service added!").show();
                clearFields();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void clearFields() {
        txtSerId.clear();
        txtSerName.clear();
        txtSerType.clear();
        txtSerAmount.clear();
    }

    @FXML
    void btnUpdateOnAction(ActionEvent event) {
        String id = txtSerId.getText();
        String name = txtSerName.getText();
        String type = txtSerType.getText();
        double amount = Double.parseDouble(txtSerAmount.getText());

            var dto = new ServiceDto(id, name, type, amount);

            //var model = new ServiceModel();
        boolean isUpdated = false;
        try {
            isUpdated = serviceModel.updateService(dto);
            if(isUpdated) {
                new Alert(Alert.AlertType.CONFIRMATION, "service updated!").show();
                clearFields();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void txtSearchOnAction(ActionEvent event) {
        String id = txtSerId.getText();

       // var model = new ServiceModel();
        ServiceDto serviceDto = null;
        try {
            serviceDto = serviceModel.searchService(id);

            System.out.println(serviceDto);
            if (serviceDto != null) {
                txtSerId.setText(serviceDto.getServiceId());
                txtSerName.setText(serviceDto.getServiceName());
                txtSerType.setText(serviceDto.getServiceType());
                txtSerAmount.setText(String.valueOf(serviceDto.getServiceAmount()));
            } else {
                new Alert(Alert.AlertType.INFORMATION, "service not found").show();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
