package lk.ijse.salon.model;

public class PaymentModel {
}
