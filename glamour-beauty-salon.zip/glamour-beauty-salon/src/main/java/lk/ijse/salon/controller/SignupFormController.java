package lk.ijse.salon.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.salon.dto.LoginDto;
import lk.ijse.salon.dto.SignupDto;
import lk.ijse.salon.model.SignupModel;

import java.io.IOException;
import java.sql.SQLException;

public class SignupFormController {

    @FXML
    private AnchorPane signuppage;

    @FXML
    private TextField txtEmail;

    @FXML
    private Button btnSignup;

    @FXML
    private TextField txtPassword;

    @FXML
    private TextField txtFullName;
    static SignupModel signupModel = new SignupModel();

    @FXML
    void btnSignupOnAction(ActionEvent event) {
        String fullName = txtFullName.getText();
        String email = txtEmail.getText();
        String password = txtPassword.getText();

        SignupDto signupDto = new SignupDto(fullName, email, password);

        try {
            boolean isSignup = signupModel.userSignup(signupDto);
            if(isSignup) {
                new Alert(Alert.AlertType.INFORMATION, "Signup Success").show();
                navigateToMainWindow();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void navigateToMainWindow() throws IOException {
        Parent rootNode = FXMLLoader.load(this.getClass().getResource("/view/main_form.fxml"));
        Scene scene = new Scene(rootNode);

        signuppage.getChildren().clear();
        Stage primaryStage = (Stage) signuppage.getScene().getWindow();

        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();
        primaryStage.setTitle("Main Form");
    }

    @FXML
    void loginOnAction(ActionEvent event) throws IOException {
        Parent rootNode = FXMLLoader.load(this.getClass().getResource("/view/login_form.fxml"));

        Scene scene = new Scene(rootNode);

        signuppage.getChildren().clear();
        Stage primaryStage = (Stage) signuppage.getScene().getWindow();

        primaryStage.setScene(scene);
        primaryStage.setTitle("Login Form");
    }

}
